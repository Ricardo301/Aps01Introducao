#include <stdio.h>
#include <stdlib.h>

int main(){
	int num;
	printf("Digite um numero: ");
	scanf("%d",&num);
	printf("\n");
	
	if(num>=55 && num<=85){
		printf("Numero entre 55 e 85\n");
	}
	 if (num>=70 && num<=105){
		printf("Numero entre 70 e 105\n");
	}
	 if (num>=100 && num<=170){
		printf("Numero entre 100 e 170\n");
	}
	
	return 0;
	
}
